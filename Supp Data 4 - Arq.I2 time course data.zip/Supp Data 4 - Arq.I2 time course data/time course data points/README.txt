Please note that the percentage of precursor tends to be less than 100% at t=0.
This is not because the reaction has already progressed, but due to noise in the gel image.
To remedy this PRE was set to 100, and BRANCHED and LIN were set to 0 at t=0 for all datasets before they were used for fitting the kinetic model.