from Bio import AlignIO

# Read the alignment file
alignment = AlignIO.read("Pli2_vs_Pli1_vs_Arq_introns_aligned.fasta", "fasta")
query_seq = alignment[0].seq  # Assuming the first sequence is the query
query_length = len(query_seq)  # Include gaps in the query length
query_id = alignment[0].id

# Define the maximum number of characters per line
max_chars = 60

# Open a file to write the results
with open("alignment_results.fasta", "w") as output_file:
    for record in alignment[1:]:
        both_gaps = 0
        matches = 0
        for q, r in zip(query_seq, record.seq):
            if q == '-' and r == '-':
                both_gaps += 1
            elif q == r and r != '-':
                matches += 1

        adjusted_query_length = query_length - both_gaps
        identity = (matches / adjusted_query_length) * 100 if adjusted_query_length > 0 else 0

        # Create alignment visualization
        match_line = ''.join('|' if q == r and r != '-' else ' ' for q, r in zip(query_seq, record.seq))

        # Prepare output header
        header = f">{query_id} vs {record.id} - {identity:.2f}% identity"

        # Write header to file
        output_file.write(f"{header}\n")

        # Convert sequences to strings so we can slice them easily
        query_line = str(query_seq)
        record_line = str(record.seq)

        # Write the alignment in chunks of max_chars length
        for i in range(0, len(query_line), max_chars):
            # Get a slice from each sequence for the current chunk
            q_chunk = query_line[i:i+max_chars]
            m_chunk = match_line[i:i+max_chars]
            r_chunk = record_line[i:i+max_chars]

            # Write each chunk to the file
            output_file.write(f"{q_chunk}\n")
            output_file.write(f"{m_chunk}\n")
            output_file.write(f"{r_chunk}\n\n")

        # Optionally add an extra blank line for separation between alignments
        output_file.write("\n")
